<?php // Sekiranya button submit diklik

// isset = is setted to ?
if (isset($_GET["cmdregister"])) {
    // receive submitted value
    $title = $_GET["cbotitle"];
    $ic = $_GET["txticcustomer"];
    $name = $_GET["txtnamacustomer"];
    $phone_customer = $_GET["txttelefoncustomer"];
    $family = $_GET["cbobilkeluarga"];
    $noplet = $_GET["txtnopletcustomer"];
    $email = $_GET["txtEmailcustomer"];
    $username = $_GET["txtusercustomer"];
    $password = hash("sha512", $_GET["txtpwdcustomer"]);

    if (intval(substr($ic, 11, 1)) % 2 == 1) {
        $jantina = "J";
    } else {
        $jantina = "B";
    }

    $icnum = substr($ic, 8, 4);
    $phone = substr($phone_customer, 6, 4);

    $id = $jantina . $icnum . $phone;

    //Create Connection to the database
    include 'conn.php';

    // SQL Login
    $sql_login = "INSERT INTO `tbllogin`(`idcustomer`, `username`, `password`) 
    VALUES ('$id','$username','$password')";

    // SQL Customer
    $sql_customer = "INSERT INTO `tblcustomer`(`idcustomer`, `ic`, `title` , `nama`, `notelefon`, `bilkeluarga`, `noplet`, `email`) 
    VALUES ('$id','$ic','$title','$name','$phone_customer','$family','$noplet','$email')";


    //Execute SQL Login Statement
    $res = mysqli_query($con, $sql_login);

    //Execute SQL Customer Statement
    $res = mysqli_query($con, $sql_customer);

    //Close Con
    mysqli_close($con);

    //Prompt to the user.
    echo "<script>alert('Your registration is successful. Please proceed to the login page');</script>";

    //Redirect to page ---> Login.php
    echo "<script>window.location.href='login.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>sbs</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="images/fevicon.png" type="image/gif" />
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<!-- body -->

<body class="main-layout inner_page">
    <!-- loader  -->
    <div class="loader_bg">
        <div class="loader"><img src="images/loading.gif" alt="#" /></div>
    </div>
    <!-- end loader -->
    <!-- header -->
    <div class="header">
        <div class="container-fluid">
            <div class="row d_flex">
                <div class=" col-md-2 col-sm-3 col logo_section">
                    <div class="full">
                        <div class="center-desk">
                            <div class="logo">
                                <a href="index.html"><img src="gg.jpeg" alt="#" /></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8 col-sm-12">
                    <nav class="navigation navbar navbar-expand-md navbar-dark ">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                            <ul class="navbar-nav mr-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.html">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="about.html">Accommodation</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="skating.html">Dining</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="shop.html">Spa</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.html">Gallary</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- end header inner -->

    <!-- Registration Form Start -->
    <div class="contact">
        <div class="container">
            <div class="row ">
                <div class="col-md-12">
                    <div class="titlepage text_align_center">
                        <h2>Contact Us</h2>
                    </div>
                </div>
                <div class="col-md-12">
                    <form name="frmregisteration" class="main_form" action="" method="get">
                        <div class="row">
                            <div class="row">
                                <!-- TITLE -->
                                <div class="col-md-6 select-outline">
                                    <select class="custom-select " name="cbotitle">
                                        <option selected>Title*</option>
                                        <option value="Dato">Dato'</option>
                                        <option value="Datin">Datin'</option>
                                        <option value="LIGMA">WOI</option>
                                    </select>
                                </div>
                                <!-- IC -->
                                <div class="col-md-6">
                                    <input class="contactus" placeholder="IC Number*" type="text" name="txticcustomer">
                                </div>
                                <!-- NAMA -->
                                <div class="col-md-12">
                                    <input class="contactus" placeholder="Nama*" type="text" name="txtnamacustomer">
                                </div>
                                <!-- NO. FON -->
                                <div class="col-md-6">
                                    <input class="contactus" placeholder="Nombor Telefon*" type="text" name="txttelefoncustomer">
                                </div>
                                <!-- BIL KELUARGA -->
                                <div class="col-md-6 select-outline">
                                    <select class="custom-select " name="cbobilkeluarga">
                                        <option selected>Bilangan Ahli Keluarga*</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                    </select>
                                </div>
                                <!-- NO. PLET -->
                                <div class="col-md-6">
                                    <input class="contactus" placeholder="No Plet*" type="text" name="txtnopletcustomer">
                                </div>
                                <!-- EMAIL -->
                                <div class="col-md-6">
                                    <input class="contactus" placeholder="Email*" type="text" name="txtEmailcustomer">
                                </div>
                                <!-- USERNAME -->
                                <div class="col-md-6">
                                    <input class="contactus" placeholder="Username*" type="text" name="txtusercustomer">
                                </div>
                                <!-- PASSWORD -->
                                <div class="col-md-6">
                                    <input class="contactus" placeholder="Password*" type="password" name="txtpwdcustomer">
                                </div>
                                <!-- SUBMIT -->
                                <div class="col-md-12">
                                    <button class="send_btn" name="cmdregister">Register</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Registration Form End -->

    <!--  footer -->
    <footer>
        <div class="footer">
            <div class="copyright">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <p>© 2024 Hak Cipta Terpelihara. Stolen By Archon Daun</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- end footer -->
    <!-- Javascript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery-3.0.0.min.js"></script>
    <!-- sidebar -->
    <script src="js/custom.js"></script>
    <script>
        AOS.init();
    </script>
</body>

</html>