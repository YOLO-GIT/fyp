<?php

$host = "localhost";
$user = "id21576521_root";
$pass = "LibraryPro1234+5";
$db = "id21576521_dbopac";

$con = mysqli_connect($host, $user, $pass, $db);

if (!$con) {
    die("Database failed");
}

// Connection mg lah jim
